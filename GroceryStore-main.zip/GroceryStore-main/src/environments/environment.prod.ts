export const environment = {
  production: true,
  firebase: {
    apiKey: "AIzaSyByiB4amcQOlaq_fe7KReziOwbz2fnaiIY",
    authDomain: "grocery-store-b4750.firebaseapp.com",
    databaseURL: "https://grocery-store-b4750-default-rtdb.firebaseio.com",
    projectId: "grocery-store-b4750",
    storageBucket: "grocery-store-b4750.appspot.com",
    messagingSenderId: "325024488638",
    appId: "1:325024488638:web:98ac7020b65af05b5652ef",
    measurementId: "G-TXM5QXMQFB"
  }
};
