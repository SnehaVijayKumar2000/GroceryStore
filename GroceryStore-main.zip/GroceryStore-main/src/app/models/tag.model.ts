export class Tag{
  name!:string;
}
