export interface Item {
    id: string,
    name: string,
    discription : string,
    photo_ref : string,
    price : number
    tags : string[]
}