# GroceryStore

An online Grocery Store allows customers to place orders for items and/or services from a store that caters to both walk-in and online shoppers. The online Store system displays everything they intend to sell on the internet. Customers can use this web-based application to select products and add them to their shopping cart. Customers enter their address and contact information, and their desired products are delivered to their home. Customers will save a lot of time by using this Web application.

## Development server

Run `ng serve` for a dev server. Navigate to `http://localhost:4200/`. The app will automatically reload if you change any of the source files.

## Build

Run `ng build` to build the project. The build artifacts will be stored in the `dist/` directory.

## Running unit tests

Run `ng test` to execute the unit tests via [Karma](https://karma-runner.github.io).
